// helloWorld.js
exports.helloWorld = (req, res) => {
	res.send("Hello, Pulumi on GCP!");
};
